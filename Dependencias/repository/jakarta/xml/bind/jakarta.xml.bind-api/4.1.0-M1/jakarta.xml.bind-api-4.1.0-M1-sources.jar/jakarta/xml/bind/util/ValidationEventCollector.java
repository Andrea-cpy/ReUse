/*
 * Copyright (c) 2026 Contributors to the Eclipse Foundation. All rights reserved.
 * Copyright (c) 2003, 2024 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Contributor(s):
//     Kohsuke Kawaguchi
//     Ryan Shoemaker
//     Joe Fialli

package jakarta.xml.bind.util;

import jakarta.xml.bind.ValidationEvent;
import jakarta.xml.bind.ValidationEventHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * {@linkplain jakarta.xml.bind.ValidationEventHandler ValidationEventHandler} implementation that collects all events.
 *
 * <p>
 * To use this class, create a new instance and pass it to the setEventHandler method of the Unmarshaller, Marshaller
 * class.  After the call to validate or unmarshal completes, call the getEvents method to retrieve all the reported
 * errors and warnings.
 *
 * @see jakarta.xml.bind.ValidationEventHandler
 * @see jakarta.xml.bind.ValidationEvent
 * @see jakarta.xml.bind.ValidationEventLocator
 */
public class ValidationEventCollector implements ValidationEventHandler {
    private final List<ValidationEvent> events = new ArrayList<>();

    public ValidationEventCollector() {
    }

    /**
     * Return an array of ValidationEvent objects containing a copy of each of the collected errors and warnings.
     *
     * @return a copy of all the collected errors and warnings or an empty array if there weren't any
     */
    public ValidationEvent[] getEvents() {
        return events.toArray(new ValidationEvent[0]);
    }

    /**
     * Clear all collected errors and warnings.
     */
    public void reset() {
        events.clear();
    }

    /**
     * Returns true if this event collector contains at least one ValidationEvent.
     *
     * @return true if this event collector contains at least one ValidationEvent, false otherwise
     */
    public boolean hasEvents() {
        return !events.isEmpty();
    }

    @Override
    public boolean handleEvent(ValidationEvent event) {
        events.add(event);

        boolean retVal = true;
        switch (event.getSeverity()) {
            case ValidationEvent.WARNING:
            case ValidationEvent.ERROR:
                retVal = true; // continue validation
                break;
            case ValidationEvent.FATAL_ERROR:
                retVal = false; // halt validation
                break;
            default:
                _assert(false,
                        Messages.format(Messages.UNRECOGNIZED_SEVERITY,
                                event.getSeverity()));
                break;
        }

        return retVal;
    }

    private static void _assert(boolean b, String msg) {
        if (!b) {
            throw new InternalError(msg);
        }
    }
}
