/*
 * Copyright (c) 2026 Contributors to the Eclipse Foundation. All rights reserved.
 * Copyright (c) 2003, 2024 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Contributor(s):
//     Ryan Shoemaker
//     Kohsuke Kawaguchi
//     Joe Fialli

package jakarta.xml.bind;

/**
 * This is an element marker interface.
 * <p>
 * Under certain circumstances, it is necessary for the binding compiler to generate derived java content classes that
 * implement this interface.  In those cases, client applications must supply element instances rather than types of
 * elements.  For more detail, see section 5.7 "Element Declaration" and 5.7.1 "Bind to Java Element Interface" of the
 * specification.
 *
 */
public interface Element {
}
