/*
 * Copyright (c) 2026 Contributors to the Eclipse Foundation. All rights reserved.
 * Copyright (c) 2005, 2024 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Contributor(s):
//     Kohsuke Kawaguchi

package jakarta.xml.bind.annotation;

import jakarta.activation.DataHandler;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Marks a field/property that its XML form is a URI reference to mime content. The mime content is optimally stored
 * out-of-line as an attachment.
 * <p>
 * A field/property must always map to the {@linkplain DataHandler} class.
 *
 * <h2>Usage</h2>
 * {@snippet :
 *  @XmlRootElement
 *  class Foo {
 *      @XmlAttachmentRef
 *      @XmlAttribute
 *      DataHandler data;
 *
 *      @XmlAttachmentRef
 *      @XmlElement
 *      DataHandler body;
 *  }
 *} The above code maps to the following XML:
 * {@snippet lang = "XML":
 *  <xs:element name="foo" xmlns:ref="http://ws-i.org/profiles/basic/1.1/xsd">
 *    <xs:complexType>
 *      <xs:sequence>
 *        <xs:element name="body" type="ref:swaRef" minOccurs="0" />
 *      </xs:sequence>
 *      <xs:attribute name="data" type="ref:swaRef" use="optional" />
 *    </xs:complexType>
 *  </xs:element>
 *}
 *
 * <p>
 * The above binding supports WS-I AP 1.0 <a
 * href="http://www.ws-i.org/Profiles/AttachmentsProfile-1.0.html#Referencing_Attachments_from_the_SOAP_Envelope">WS-I
 * Attachments Profile Version 1.0.</a>
 */
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER})
public @interface XmlAttachmentRef {
}
