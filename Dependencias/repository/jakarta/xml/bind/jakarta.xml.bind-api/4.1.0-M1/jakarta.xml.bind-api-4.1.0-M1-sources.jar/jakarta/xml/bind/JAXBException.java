/*
 * Copyright (c) 2026 Contributors to the Eclipse Foundation. All rights reserved.
 * Copyright (c) 2003, 2021 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Contributor(s):
//     Ryan Shoemaker

package jakarta.xml.bind;

import java.io.PrintWriter;
import java.io.Serial;

/**
 * This is the root exception class for all Jakarta XML Binding exceptions.
 *
 * @see JAXBContext
 * @see Marshaller
 * @see Unmarshaller
 */
public class JAXBException extends Exception {

    /**
     * Vendor specific error code
     *
     */
    private String errorCode;

    /**
     * Exception reference
     *
     */
    private volatile Throwable linkedException;

    @Serial
    private static final long serialVersionUID = -5621384651494307979L;

    /**
     * Construct a JAXBException with the specified detail message.  The errorCode and linkedException will default to
     * null.
     *
     * @param message a description of the exception
     */
    public JAXBException(String message) {
        this(message, null, null);
    }

    /**
     * Construct a JAXBException with the specified detail message and vendor specific errorCode.  The linkedException
     * will default to null.
     *
     * @param message   a description of the exception
     * @param errorCode a string specifying the vendor specific error code
     */
    public JAXBException(String message, String errorCode) {
        this(message, errorCode, null);
    }

    /**
     * Construct a JAXBException with a linkedException.  The detail message and vendor specific errorCode will default
     * to null.
     *
     * @param exception the linked exception
     */
    public JAXBException(Throwable exception) {
        this(null, null, exception);
    }

    /**
     * Construct a JAXBException with the specified detail message and linkedException.  The errorCode will default to
     * null.
     *
     * @param message   a description of the exception
     * @param exception the linked exception
     */
    public JAXBException(String message, Throwable exception) {
        this(message, null, exception);
    }

    /**
     * Construct a JAXBException with the specified detail message, vendor specific errorCode, and linkedException.
     *
     * @param message   a description of the exception
     * @param errorCode a string specifying the vendor specific error code
     * @param exception the linked exception
     */
    public JAXBException(String message, String errorCode, Throwable exception) {
        super(message);
        this.errorCode = errorCode;
        this.linkedException = exception;
    }

    /**
     * Get the vendor specific error code
     *
     * @return a string specifying the vendor specific error code
     */
    public String getErrorCode() {
        return this.errorCode;
    }

    /**
     * Get the linked exception
     *
     * @return the linked Exception, null if none exists
     */
    public Throwable getLinkedException() {
        return linkedException;
    }

    /**
     * Add a linked Exception.
     *
     * @param exception the linked Exception (A null value is permitted and indicates that the linked exception does not
     *                  exist or is unknown).
     */
    public void setLinkedException(Throwable exception) {
        this.linkedException = exception;
    }

    /**
     * Returns a short description of this JAXBException.
     *
     */
    @Override
    public String toString() {
        return linkedException == null ?
                super.toString() :
                super.toString() + "\n - with linked exception:\n[" +
                        linkedException.toString() + "]";
    }

    /**
     * Prints this JAXBException and its stack trace (including the stack trace of the linkedException if it is
     * non-null) to the PrintStream.
     *
     * @param s PrintStream to use for output
     */
    @Override
    public void printStackTrace(java.io.PrintStream s) {
        super.printStackTrace(s);
    }

    /**
     * Prints this JAXBException and its stack trace (including the stack trace of the linkedException if it is
     * non-null) to {@code System.err}.
     *
     */
    @Override
    public void printStackTrace() {
        super.printStackTrace();
    }

    /**
     * Prints this JAXBException and its stack trace (including the stack trace of the linkedException if it is
     * non-null) to the PrintWriter.
     *
     * @param s PrintWriter to use for output
     */
    @Override
    public void printStackTrace(PrintWriter s) {
        super.printStackTrace(s);
    }

    @Override
    public Throwable getCause() {
        return linkedException;
    }
}
