/*
 * Copyright (c) 2026 Contributors to the Eclipse Foundation. All rights reserved.
 * Copyright (c) 2005, 2024 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Contributor(s):
//     Kohsuke Kawaguchi

package jakarta.xml.bind.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Map;

import javax.xml.namespace.QName;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * <p>
 * Maps a JavaBean property to a map of wildcard attributes.
 *
 * <p> <b>Usage</b> </p>
 * <p>
 * The {@code @XmlAnyAttribute} annotation can be used with the following program elements:
 * <ul>
 *   <li> JavaBean property </li>
 *   <li> non-static, non transient field </li>
 * </ul>
 *
 * <p>See "Package Specification" in jakarta.xml.bind.package javadoc for
 * additional common information.</p>
 * <p>
 * The usage is subject to the following constraints:
 * <ul>
 *   <li> At most one field or property in a class can be annotated
 *        with {@code @XmlAnyAttribute}.  </li>
 *   <li> The type of the property or the field must {@code java.util.Map} </li>
 * </ul>
 *
 * <p>
 * While processing attributes to be unmarshalled into a value class,
 * each attribute that is not statically associated with another
 * JavaBean property, via {@linkplain XmlAttribute}, is entered into the
 * wildcard attribute map represented by
 * {@linkplain Map}&lt;{@linkplain QName},{@linkplain Object}&gt;. The attribute QName is the
 * map's key. The key's value is the String value of the attribute.
 */
@Retention(RUNTIME)
@Target({FIELD, METHOD})
public @interface XmlAnyAttribute {
}
