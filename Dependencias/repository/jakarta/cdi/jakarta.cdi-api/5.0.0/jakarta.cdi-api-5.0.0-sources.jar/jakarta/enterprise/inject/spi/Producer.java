/*
 * Copyright 2010, Red Hat, Inc., and individual contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.enterprise.inject.spi;

import java.util.Set;

import jakarta.enterprise.context.spi.CreationalContext;

/**
 * <p>
 * Provides a generic operation for producing an instance of a type.
 * </p>
 *
 * <p>
 * CDI Lite implementations are not required to provide support for {@code Producer}.
 * </p>
 *
 * @author Pete Muir
 * @author David Allen
 * @param <T> The class of object produced by the producer
 */
public interface Producer<T> {
    /**
     * <p>
     * Causes an instance to be produced via the {@code Producer}.
     * </p>
     * <p>
     * If the {@code Producer} represents a managed bean, this will invoke the constructor annotated
     * {@link jakarta.inject.Inject} if it exists, or the constructor with no parameters otherwise.
     * If the bean has interceptors or decorators, {@code produce()} is responsible for building
     * the interceptors and decorators of the instance.
     * </p>
     * <p>
     * If the {@code Producer} represents a producer field or method, this will invoke the producer method on,
     * or access the producer field of, a contextual instance of the bean that declares the producer.
     * </p>
     *
     * @param ctx The {@link CreationalContext} to use for the produced object
     * @return the instance produced
     */
    public T produce(CreationalContext<T> ctx);

    /**
     * <p>
     * Destroys the instance.
     * </p>
     * <p>
     * If the {@code Producer} represents a managed bean, then this operation does only one thing:
     * if the bean is auto-closeable and the class of the contextual instance implements {@link AutoCloseable},
     * {@code close()} is called on the instance.
     * </p>
     * <p>
     * If the {@code Producer} represents a producer field or method, this calls the disposer method, if any, on a contextual
     * instance of the bean that declares the disposer method or performs any additional required cleanup, if any, to destroy
     * state associated with a resource. Then, if the bean is auto-closeable and the class of the contextual instance
     * implements {@link AutoCloseable}, {@code close()} is called on the instance.
     * </p>
     *
     * @param instance The instance to dispose
     */
    public void dispose(T instance);

    /**
     * <p>
     * Returns the set of all {@code InjectionPoint}s. If the {@code Producer} represents a managed bean, then this returns
     * the set of {@code InjectionPoint} objects representing all injected fields, bean constructor parameters and initializer
     * method parameters. For a producer method, this returns the set of {@code InjectionPoint} objects representing all
     * parameters of the producer method. For a producer field, this returns an empty set.
     * </p>
     *
     * @return the set of all {@linkplain InjectionPoint injection points} for the producer
     */
    public Set<InjectionPoint> getInjectionPoints();
}