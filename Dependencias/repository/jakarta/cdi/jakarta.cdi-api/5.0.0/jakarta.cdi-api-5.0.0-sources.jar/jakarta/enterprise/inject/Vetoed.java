/*
 * Copyright 2013, Red Hat, Inc., and individual contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jakarta.enterprise.inject;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.enterprise.event.Event;
import jakarta.enterprise.util.AnnotationLiteral;

/**
 * <p>
 * Veto the processing of the class. Any beans or observer methods defined by this class will not be installed.
 * </p>
 *
 * <p>
 * When placed on package, all beans in the package are prevented from being installed. If packages are split across jars,
 * non-portable behavior results. An application can prevent packages being split across jars by sealing the package.
 * </p>
 *
 * <p>
 * No container lifecycle events are fired for classes annotated {@link Vetoed}.
 * </p>
 *
 * @author Stuart Douglas
 * @since 1.1
 * @see <a href="https://docs.oracle.com/javase/8/docs/technotes/guides/jar/jar.html#sealing">JAR File Specification</a>
 *
 */
@Target({ ElementType.TYPE, ElementType.PACKAGE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Vetoed {

    /**
     * Supports inline instantiation of the {@link Vetoed} annotation.
     *
     * @author Martin Kouba
     * @since 2.0
     * @see Instance
     * @see Event
     */
    final class Literal extends AnnotationLiteral<Vetoed> implements Vetoed {
        private static final long serialVersionUID = 1L;
        /** Default Vetoed literal */
        public static final Literal INSTANCE = new Literal();

        public Class<? extends Annotation> annotationType() {
            return Vetoed.class;
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            } else {
                return other instanceof Annotation that && Vetoed.class.equals(that.annotationType());
            }
        }

        public int hashCode() {
            return 0;
        }

        public String toString() {
            return "@jakarta.enterprise.inject.Vetoed()";
        }
    }

}
