/*
 * Copyright 2010, Red Hat, Inc., and individual contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jakarta.enterprise.inject.spi;

import static java.util.Arrays.asList;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * <p>
 * Represents a constructor of a Java class.
 * </p>
 *
 * @author Gavin King
 * @author Pete Muir
 *
 * @param <X> the declaring class
 * @see Constructor
 */
public interface AnnotatedConstructor<X> extends AnnotatedCallable<X> {

    /**
     * <p>
     * Get the underlying {@link Constructor}.
     * </p>
     *
     * @return the constructor
     */
    public Constructor<X> getJavaMember();

    @Override
    default <T extends Annotation> Set<T> getAnnotations(Class<T> annotationType) {
        T[] annotationsByType = getJavaMember().getAnnotationsByType(annotationType);
        return new LinkedHashSet<>(asList(annotationsByType));
    }
}
