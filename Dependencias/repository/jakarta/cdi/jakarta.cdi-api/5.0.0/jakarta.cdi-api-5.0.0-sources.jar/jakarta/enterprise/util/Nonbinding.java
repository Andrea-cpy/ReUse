/*
 * Copyright 2010, Red Hat, Inc., and individual contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jakarta.enterprise.util;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * <p>
 * Excludes a member of an annotation type (such as a {@linkplain jakarta.inject.Qualifier qualifier type} or
 * {@linkplain jakarta.interceptor.InterceptorBinding interceptor binding type}) from consideration when the container compares
 * two annotation instances.
 * </p>
 *
 * <pre>
 * &#064;Qualifier
 * &#064;Retention(RUNTIME)
 * &#064;Target({ METHOD, FIELD, PARAMETER, TYPE })
 * public @interface PayBy {
 *     PaymentMethod value();
 *
 *     &#064;Nonbinding
 *     String comment();
 * }
 * </pre>
 *
 * @author Gavin King
 *
 * @see jakarta.inject.Qualifier &#064;Qualifier
 * @see jakarta.interceptor.InterceptorBinding &#064;InterceptorBinding
 *
 */
@Retention(RUNTIME)
@Target(METHOD)
public @interface Nonbinding {

    /**
     * Supports inline instantiation of the {@link Nonbinding} annotation.
     *
     * @author Martin Kouba
     * @since 2.0
     */
    final class Literal extends AnnotationLiteral<Nonbinding> implements Nonbinding {
        /** Default Nonbinding literal */
        public static final Literal INSTANCE = new Literal();

        private static final long serialVersionUID = 1L;

        public Class<? extends Annotation> annotationType() {
            return Nonbinding.class;
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            } else {
                return other instanceof Annotation that && Nonbinding.class.equals(that.annotationType());
            }
        }

        public int hashCode() {
            return 0;
        }

        public String toString() {
            return "@jakarta.enterprise.util.Nonbinding()";
        }
    }
}
