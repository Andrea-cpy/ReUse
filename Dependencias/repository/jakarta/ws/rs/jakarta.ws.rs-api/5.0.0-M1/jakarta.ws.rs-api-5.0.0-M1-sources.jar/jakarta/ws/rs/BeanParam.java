/*
 * Copyright (c) 2012, 2019 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0, which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the
 * Eclipse Public License v. 2.0 are satisfied: GNU General Public License,
 * version 2 with the GNU Classpath Exception, which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 */

package jakarta.ws.rs;

import java.io.Serial;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.enterprise.util.AnnotationLiteral;
import jakarta.inject.Qualifier;

/**
 * The annotation that may be used to inject custom JAX-RS "parameter aggregator" value object into a resource class
 * field, property or resource method parameter.
 * <p>
 * When running with an active CDI container, the bean is created and injected by CDI like any other CDI-managed
 * type: fields and properties annotated with {@link jakarta.inject.Inject &#64;Inject} are injected normally, and
 * fields and properties annotated with one of the {@code @XxxParam} annotations ({@link PathParam &#64;PathParam},
 * {@link FormParam &#64;FormParam} ...) are resolved from the current request context using the same CDI qualifier
 * mechanism used for resource method parameters.
 * <p>
 * Without an active CDI container, the JAX-RS runtime instantiates the object and injects all its fields and
 * properties annotated with one of the {@code @XxxParam} annotations. For the POJO classes the same instantiation
 * and injection rules apply as in the case of instantiation and injection of request-scoped root resource classes.
 * </p>
 * For example:
 *
 * <PRE>
 * public class MyBean {
 *   &#64;FormParam("myData")
 *   private String data;
 *
 *   &#64;HeaderParam("myHeader")
 *   private String header;
 *
 *   &#64;PathParam("id")
 *   public void setResourceId(String id) {...}
 *
 *   ...
 * }
 *
 * &#64;Path("myresources")
 * public class MyResources {
 *   &#64;POST
 *   &#64;Path("{id}")
 *   public void post(&#64;BeanParam MyBean myBean) {...}
 *
 *   ...
 * }
 * </PRE>
 * <p>
 * Because injection occurs at object creation time, use of this annotation on resource class fields and bean properties
 * is only supported for the default per-request resource class lifecycle. Resource classes using other lifecycles
 * should only use this annotation on resource method parameters.
 * </p>
 *
 * @author Marek Potociar
 * @since 2.0
 */
@Target({ ElementType.PARAMETER, ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Qualifier
public @interface BeanParam {

    /**
     * Supports inline instantiation of the {@link BeanParam} annotation.
     * @since 5.0
     */
    final class Literal extends AnnotationLiteral<BeanParam> implements BeanParam {
        @Serial
        private static final long serialVersionUID = 1L;

        /**
         * Default BeanParam literal
         */
        public static final BeanParam INSTANCE = new Literal();

        private Literal() {}
    }
}
